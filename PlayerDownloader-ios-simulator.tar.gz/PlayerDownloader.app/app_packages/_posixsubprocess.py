"""Shim mínimo para o iOS.

O build do CPython para iOS não inclui o módulo de extensão `_posixsubprocess`
(o iOS não permite criar processos). Várias bibliotecas — inclusive o yt-dlp —
fazem `import subprocess` no topo do módulo, e o `subprocess` da stdlib importa
`fork_exec` de `_posixsubprocess` incondicionalmente no POSIX. Sem este arquivo,
`import yt_dlp` falha antes de qualquer download.

Nada aqui cria processos: se alguém realmente tentar usar `subprocess`, recebe um
OSError claro. O motor do iOS baixa com URLSession/AVFoundation, não com processos.
"""

from __future__ import annotations

from typing import Any


def fork_exec(*_args: Any, **_kwargs: Any) -> None:
    raise OSError("subprocess não é suportado no iOS; use o downloader nativo.")
