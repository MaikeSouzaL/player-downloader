"""Motor local de download do Player Downloader no iOS.

Este pacote roda dentro do CPython embutido no app. Ele não abre servidor, não usa
cookies e não chama o backend: o yt-dlp fala direto com o site pela conexão do aparelho.
"""

__version__ = "1.0.0"
