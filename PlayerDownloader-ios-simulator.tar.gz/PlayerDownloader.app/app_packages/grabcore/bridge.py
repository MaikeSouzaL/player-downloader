"""Ponte JSON chamada pelo C embutido (GrabPython.c).

O Swift nunca importa Python: manda um dicionário JSON e recebe outro. Toda exceção
vira um dicionário com `error`/`message`, para o app não derrubar a thread nativa.
"""

from __future__ import annotations

import sys
import traceback
from typing import Any

from . import extract, selftest
from .errors import GrabCancelled, GrabError


def _error(code: str, message: str, *, include_traceback: bool = False) -> dict[str, Any]:
    result: dict[str, Any] = {"ok": False, "error": code, "message": message}
    if include_traceback:
        result["traceback"] = traceback.format_exc()[-4000:]
    return result


def handle(request: Any) -> dict[str, Any]:
    if not isinstance(request, dict):
        return _error("ERR_GRAB_REQUEST", "Requisição inválida.")

    action = str(request.get("action") or "")
    try:
        if action == "available":
            return {
                "ok": True,
                "python": sys.version,
                "platform": sys.platform,
                "version": __import__("grabcore").__version__,
            }

        if action == "selftest":
            return selftest.run(request)

        if action == "resolve":
            url = str(request.get("url") or "").strip()
            if not url:
                return _error("ERR_GRAB_URL", "Link vazio.")
            return extract.resolve(url, bool(request.get("playlist")))

        if action == "search":
            query = str(request.get("query") or "").strip()
            if not query:
                return _error("ERR_GRAB_QUERY", "Busca vazia.")
            return extract.search(query, int(request.get("limit") or 15))

        if action == "start":
            # M1: a ponte existe e responde; o download em background é a fase M3.
            return _error(
                "ERR_GRAB_NOT_IMPLEMENTED",
                "O download no iPhone chega na próxima fase do motor local.",
            )

        if action == "jobs":
            ids = request.get("ids") or []
            if not isinstance(ids, list):
                ids = []
            return {"ok": True, "jobs": [], "missing": [str(item) for item in ids]}

        if action == "cancel":
            return {"ok": True}

        return _error("ERR_GRAB_ACTION", f"Ação desconhecida: {action or '(vazia)'}")

    except GrabCancelled as exc:
        return _error(exc.code, str(exc))
    except GrabError as exc:
        return _error(exc.code, str(exc), include_traceback=True)
    except Exception as exc:  # noqa: BLE001 - a ponte precisa devolver erro, nunca derrubar
        return _error("ERR_GRAB_INTERNAL", f"{type(exc).__name__}: {exc}", include_traceback=True)
