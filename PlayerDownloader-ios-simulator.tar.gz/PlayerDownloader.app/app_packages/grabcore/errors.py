"""Erros do motor local, com códigos que o Swift/JS repassam sem perder o motivo."""

from __future__ import annotations


class GrabError(Exception):
    """Erro esperado do motor (link inválido, formato incompatível, etc.)."""

    code = "ERR_GRAB"

    def __init__(self, message: str, code: str | None = None) -> None:
        super().__init__(message)
        if code:
            self.code = code


class GrabCancelled(GrabError):
    code = "ERR_CANCELLED"

    def __init__(self, message: str = "Download cancelado.") -> None:
        super().__init__(message)
