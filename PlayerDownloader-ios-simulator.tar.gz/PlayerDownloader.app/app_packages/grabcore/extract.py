"""Leitura de links e busca com o yt-dlp embutido.

Este módulo só extrai metadados: nada é salvo no disco e nenhum download começa aqui.
O download em si é a fase M3 (URLSession em background + finalização no AVFoundation).
"""

from __future__ import annotations

from typing import Any

from .errors import GrabError
from .formats import audio_formats, subtitles, video_formats


def _ydl_options(*, playlist: bool = False, flat: bool = False, limit: int | None = None) -> dict[str, Any]:
    options: dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": not playlist,
        "extract_flat": flat,
        "socket_timeout": 25,
        "retries": 2,
        "extractor_retries": 2,
        "fragment_retries": 2,
        "cachedir": False,
        "noprogress": True,
        "color": "never",
        "ignoreerrors": False,
    }
    if limit:
        options["playlistend"] = limit
    return options


def _duration(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def _entry(entry: dict[str, Any]) -> dict[str, Any]:
    entry_id = str(entry.get("id") or "")
    url = entry.get("webpage_url") or entry.get("url") or ""
    url = str(url)
    if url and not url.startswith(("http://", "https://")):
        # Em playlists "flat" o yt-dlp às vezes devolve só o ID.
        extractor = str(entry.get("ie_key") or entry.get("extractor_key") or "")
        if extractor.lower() == "youtube" or entry.get("_type") == "url":
            url = f"https://www.youtube.com/watch?v={entry_id}"
    return {
        "id": entry_id,
        "url": url,
        "title": str(entry.get("title") or entry_id or "Vídeo"),
        "uploader": entry.get("uploader") or entry.get("channel"),
        "duration": _duration(entry.get("duration")),
        "thumbnail": entry.get("thumbnail"),
    }


def _video_media(info: dict[str, Any], requested_url: str) -> dict[str, Any]:
    formats = video_formats(info)
    audios = audio_formats(info)
    return {
        "ok": True,
        "kind": "video",
        "token": "",
        "url": str(info.get("webpage_url") or requested_url),
        "title": str(info.get("title") or "Vídeo"),
        "uploader": info.get("uploader") or info.get("channel"),
        "duration": _duration(info.get("duration")),
        "thumbnail": info.get("thumbnail"),
        "extractor": info.get("extractor_key") or info.get("extractor"),
        "playlist": None,
        "playlistUrl": info.get("playlist_url"),
        "formats": formats,
        "audio": audios,
        "subtitles": subtitles(info),
        "debug": {
            "format_count": len(info.get("formats") or []),
            "video_count": len(formats),
            "audio_count": len(audios),
        },
    }


def _playlist_media(info: dict[str, Any], requested_url: str) -> dict[str, Any]:
    entries = [_entry(entry) for entry in (info.get("entries") or []) if isinstance(entry, dict)]
    title = str(info.get("title") or "Playlist")
    return {
        "ok": True,
        "kind": "playlist",
        "token": "",
        "url": str(info.get("webpage_url") or requested_url),
        "title": title,
        "uploader": info.get("uploader") or info.get("channel"),
        "duration": 0,
        "thumbnail": info.get("thumbnail") or (entries[0].get("thumbnail") if entries else None),
        "extractor": info.get("extractor_key") or info.get("extractor"),
        "playlist": {"title": title, "count": len(entries), "entries": entries},
        "playlistUrl": str(info.get("webpage_url") or requested_url),
        "formats": [],
        "audio": [],
        "subtitles": [],
        "debug": {"entry_count": len(entries)},
    }


def resolve(url: str, playlist: bool = False) -> dict[str, Any]:
    """Lê um vídeo ou playlist. Playlist completa pode ser demorada (o JS já tem timeout)."""

    if not url or not url.strip():
        raise GrabError("Link vazio.", "ERR_GRAB_URL")

    try:
        import yt_dlp
    except Exception as exc:  # pragma: no cover - depende do runtime iOS
        raise GrabError(f"yt-dlp não carregou: {exc}", "ERR_GRAB_YTDLP") from exc

    try:
        with yt_dlp.YoutubeDL(_ydl_options(playlist=playlist)) as ydl:
            info = ydl.extract_info(url.strip(), download=False)
    except Exception as exc:
        raise GrabError(f"Não foi possível ler o link: {exc}", "ERR_GRAB_RESOLVE") from exc

    if not isinstance(info, dict):
        raise GrabError("O site não devolveu informações do vídeo.", "ERR_GRAB_EMPTY")

    if info.get("_type") == "playlist" or info.get("entries") is not None:
        return _playlist_media(info, url.strip())
    return _video_media(info, url.strip())


def search(query: str, limit: int = 15) -> dict[str, Any]:
    """Busca no YouTube. `extract_flat` deixa a resposta rápida e sem baixar formatos."""

    query = (query or "").strip()
    if not query:
        raise GrabError("Busca vazia.", "ERR_GRAB_QUERY")
    limit = max(1, min(int(limit or 15), 30))

    try:
        import yt_dlp
    except Exception as exc:  # pragma: no cover - depende do runtime iOS
        raise GrabError(f"yt-dlp não carregou: {exc}", "ERR_GRAB_YTDLP") from exc

    try:
        with yt_dlp.YoutubeDL(_ydl_options(flat=True, limit=limit)) as ydl:
            info = ydl.extract_info(f"ytsearch{limit}:{query}", download=False)
    except Exception as exc:
        raise GrabError(f"A busca falhou: {exc}", "ERR_GRAB_SEARCH") from exc

    entries = info.get("entries") if isinstance(info, dict) else None
    items = [_entry(entry) for entry in (entries or []) if isinstance(entry, dict)]
    return {"ok": True, "items": items}
