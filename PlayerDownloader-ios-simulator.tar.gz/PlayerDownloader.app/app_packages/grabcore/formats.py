"""Tradução dos formatos do yt-dlp para o formato que a tela do app entende.

No iOS o player usa AVFoundation: na v1 só entram MP4/H.264 até 1080p e M4A/AAC.
Os outros formatos continuam na lista, mas marcados como incompatíveis para a tela
poder escondê-los sem quebrar o mesmo contrato de dados do Android.
"""

from __future__ import annotations

from typing import Any


def _int(value: Any) -> int | None:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _codec_name(codec: str | None) -> str | None:
    if not codec or codec == "none":
        return None
    low = codec.lower()
    if low.startswith("avc") or low.startswith("h264"):
        return "H.264"
    if low.startswith("vp09") or low.startswith("vp9"):
        return "VP9"
    if low.startswith("av01") or low.startswith("av1"):
        return "AV1"
    if low.startswith("hev") or low.startswith("h265"):
        return "H.265"
    if low.startswith("mp4a") or low.startswith("aac"):
        return "AAC"
    if low.startswith("opus"):
        return "Opus"
    if low.startswith("vorbis"):
        return "Vorbis"
    return codec.split(".")[0]


def _video_label(fmt: dict[str, Any], height: int | None, codec: str | None) -> str:
    if height:
        label = f"{height}p"
        fps = _int(fmt.get("fps"))
        if fps and fps >= 50:
            label += f"{fps}"
    else:
        label = "Vídeo"
    if codec and codec != "H.264":
        label += f" · {codec}"
    if fmt.get("dynamic_range") and str(fmt["dynamic_range"]).upper() not in ("SDR", "NONE"):
        label += " HDR"
    return label


def video_formats(info: dict[str, Any]) -> list[dict[str, Any]]:
    """Formatos de vídeo, do maior para o menor, para a lista da tela."""

    result: list[dict[str, Any]] = []
    for fmt in info.get("formats") or []:
        if not isinstance(fmt, dict):
            continue
        vcodec = fmt.get("vcodec")
        if not vcodec or vcodec == "none":
            continue
        height = _int(fmt.get("height"))
        codec = _codec_name(vcodec)
        compatible = codec == "H.264" and (height or 0) <= 1080
        result.append(
            {
                "id": str(fmt.get("format_id") or ""),
                "label": _video_label(fmt, height, codec),
                "ext": str(fmt.get("ext") or "mp4"),
                "height": height,
                "fps": _float(fmt.get("fps")),
                "filesize": _int(fmt.get("filesize")) or _int(fmt.get("filesize_approx")),
                "hasAudio": fmt.get("acodec") not in (None, "none"),
                "bitrate": _int(fmt.get("tbr")) if fmt.get("tbr") else None,
                "codec": codec,
                "compatible": compatible,
            }
        )

    result.sort(
        key=lambda item: (
            0 if item.get("compatible") else 1,
            -(item.get("height") or 0),
            -(item.get("bitrate") or 0),
        )
    )
    return result


def audio_formats(info: dict[str, Any]) -> list[dict[str, Any]]:
    """Faixas só de áudio em M4A/AAC (o que o AVFoundation toca sem conversão)."""

    result: list[dict[str, Any]] = []
    for fmt in info.get("formats") or []:
        if not isinstance(fmt, dict):
            continue
        acodec = fmt.get("acodec")
        if not acodec or acodec == "none":
            continue
        if fmt.get("vcodec") not in (None, "none"):
            continue
        codec = _codec_name(acodec)
        abr = _int(fmt.get("abr"))
        result.append(
            {
                "id": str(fmt.get("format_id") or ""),
                "label": f"M4A · {abr} kbps" if abr else "M4A",
                "ext": "m4a",
                "filesize": _int(fmt.get("filesize")) or _int(fmt.get("filesize_approx")),
                "bitrate": abr,
                "codec": codec,
                "compatible": codec == "AAC",
            }
        )

    result.sort(key=lambda item: (0 if item.get("compatible") else 1, -(item.get("bitrate") or 0)))
    return result


def subtitles(info: dict[str, Any]) -> list[dict[str, Any]]:
    """Legendas disponíveis; a v1 ainda não baixa, mas a tela já recebe a lista."""

    result: list[dict[str, Any]] = []
    for lang, tracks in (info.get("subtitles") or {}).items():
        if not isinstance(tracks, list):
            continue
        for track in tracks:
            if not isinstance(track, dict):
                continue
            ext = str(track.get("ext") or "vtt")
            result.append(
                {
                    "id": f"{lang}.{ext}",
                    "lang": str(track.get("language") or lang),
                    "name": str(track.get("name") or lang),
                    "ext": ext,
                    "auto": False,
                }
            )
    return result
