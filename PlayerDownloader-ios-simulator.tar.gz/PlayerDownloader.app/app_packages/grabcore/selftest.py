"""Autoteste do motor embutido.

Roda dentro do app (ou no PC, para desenvolver) e devolve um JSON simples com versões,
caminhos e o resultado de um resolve opcional. É a única forma de validar o runtime
sem um iPhone: o build EAS embute este teste e ele pode ser chamado pelo módulo nativo.
"""

from __future__ import annotations

import os
import platform
import sys
import traceback
from typing import Any, Callable


def _check(report: dict[str, Any], name: str, func: Callable[[], Any]) -> bool:
    try:
        value = func()
        report["checks"].append({"name": name, "ok": True, "value": value})
        return True
    except Exception as exc:
        report["ok"] = False
        report["checks"].append(
            {
                "name": name,
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}",
            }
        )
        return False


def _module_version(module_name: str, attr: str = "__version__") -> str:
    import importlib

    module = importlib.import_module(module_name)
    return str(getattr(module, attr, "desconhecida"))


def _system_info() -> dict[str, Any]:
    info: dict[str, Any] = {
        "python": sys.version,
        "executable": sys.executable,
        "prefix": sys.prefix,
        "base_prefix": sys.base_prefix,
        "platform": sys.platform,
        "machine": platform.machine(),
        "path": list(sys.path),
    }
    try:
        uname = os.uname()
        info["uname"] = {
            "sysname": uname.sysname,
            "release": uname.release,
            "machine": uname.machine,
        }
    except Exception as exc:
        info["uname_error"] = f"{type(exc).__name__}: {exc}"
    return info


def run(request: dict[str, Any] | None = None) -> dict[str, Any]:
    request = request or {}
    report: dict[str, Any] = {
        "ok": True,
        "system": _system_info(),
        "checks": [],
    }

    _check(report, "ctypes", lambda: __import__("ctypes").__file__)
    _check(report, "ssl", lambda: __import__("ssl").OPENSSL_VERSION)
    _check(report, "hashlib", lambda: __import__("hashlib").algorithms_available and "ok")
    _check(report, "zlib", lambda: __import__("zlib").ZLIB_VERSION)
    _check(report, "certifi", lambda: __import__("certifi").where())
    _check(report, "yt_dlp", lambda: _module_version("yt_dlp.version", "__version__"))
    _check(report, "yt_dlp_ejs", lambda: _module_version("yt_dlp_ejs._version", "__version__"))
    _check(report, "plugin_webkit_jsi", lambda: _module_version("yt_dlp_plugins.extractor.webkit_jsi", "__version__"))

    certifi_path = None
    for check in report["checks"]:
        if check["name"] == "certifi" and check.get("ok"):
            certifi_path = check.get("value")
    if certifi_path:
        report["certifi_exists"] = os.path.exists(str(certifi_path))
        if not report["certifi_exists"]:
            report["ok"] = False

    if request.get("resolve"):
        url = str(request.get("url") or "https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        try:
            from .extract import resolve

            media = resolve(url, False)
            report["resolve"] = {
                "ok": True,
                "url": media.get("url"),
                "title": media.get("title"),
                "duration": media.get("duration"),
                "extractor": media.get("extractor"),
                "format_count": (media.get("debug") or {}).get("format_count"),
                "video_count": len(media.get("formats") or []),
                "audio_count": len(media.get("audio") or []),
            }
        except Exception as exc:
            report["ok"] = False
            report["resolve"] = {
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc()[-4000:],
            }

    return report
